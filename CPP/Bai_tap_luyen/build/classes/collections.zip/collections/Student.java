/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.kethua.collections;

import java.util.Scanner;

/**
 *
 * @author maithuyha
 */
public class Student{
    String id;
    String name;
    int level;

    public void studentInfo(){
        System.out.println("ID: ");
        id = new Scanner(System.in).nextLine();
        System.out.println("Name: ");
        name = new Scanner(System.in).nextLine();
        System.out.println("Level: ");
        level =new Scanner(System.in).nextInt();
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + ", level=" + level + '}';
    }
    
    
}
