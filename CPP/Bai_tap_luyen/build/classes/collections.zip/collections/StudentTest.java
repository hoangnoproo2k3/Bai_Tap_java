/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.kethua.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author maithuyha
 */
public class StudentTest {
    public static void main(String[] args) {
        //khai bao 1 list student
        System.out.println("khoi tao du lieu cho danh sach: ");
        List<Student> ls = new ArrayList<>();
        initList(ls);
        System.out.println("Khoi tao du lieu cho mang: ");
        Student[] arrSt = new Student[5];
       // initArray(arrSt);
        System.out.println("Hien thi ds truoc khi sap xep: ");
        showList(ls);
        System.out.println("Hien thi mang truoc khi sap xep: ");
       // showArray(arrSt);
        System.out.println("Thuc hien sap xep danh sach sinh vien: ");
       /*
        Collections.sort(ls, new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
               return o1.name.compareToIgnoreCase(o2.name) ; //To change body of generated methods, choose Tools | Templates.
            }
        });
        showList(ls);
*/
        
        System.out.println("tim kiem sinh vien theo ten: ");
        Student st = new Student();
        st.studentInfo();
        Collections.binarySearch(ls, st, new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                return o1.name.compareToIgnoreCase(o2.name); //To change body of generated methods, choose Tools | Templates.
            }
        });
    }
    
    public static void initList(List<Student> ls){
        for (int i = 0; i < 3; i++) {
            Student st = new Student();
            st.studentInfo();
            ls.add(st);
        }
    }
    
    public static void initArray(Student [] arrSt){
        for (int i = 0; i < 5; i++) {
            Student st = new Student();
            st.studentInfo();
            arrSt[i] = st;
        }
    }
    
    public static void showList(List<Student> ls){
        //su dung doi tuong Iterator de duyet
        Iterator<Student> iterator = ls.iterator();
        while(iterator.hasNext()){
            //lay ra doi tuong student trong ls de hien thi
            System.out.println("" + iterator.next().toString());
        }
    }
    
    public static void showArray(Student[] arrSt){
        for (Student student : arrSt) {
            System.out.println("" + student.toString());
        }
    }
}
