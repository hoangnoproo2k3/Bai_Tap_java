/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.kethua.collections;

import java.util.*;

/**
 *
 * @author maithuyha
 */
public class DemoCollections {
    public static void main(String[] args) {
        //danh sach dang String
        List<String> lst = new ArrayList<String>();
         //chen cac phan tu vao ds
         lst.add("Ha Noi");
         lst.add("HCM");
         lst.add("Hue");
         
         //in danh sach
         System.out.println(lst);
         //chuyen tu List sang Array
         Object[] arrObj = lst.toArray();
         System.out.println(Arrays.toString(arrObj));
         //chuyen tu List sang Array voi kieu du lieu generic
         String[] arrStr = lst.toArray(new String[0]);
         System.out.println(Arrays.toString(arrStr));
         
         System.out.println("Chuyen tu array sang list");
         List<Integer> lsInt = Arrays.asList(4,5,6);
         System.out.println(lsInt);
         List<String> ls= Arrays.asList(arrStr);
         System.out.println(ls);
    }
}
