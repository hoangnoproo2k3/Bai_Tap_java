/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.qlbh;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author maithuyha
 */
public class DSMH implements IHoatDong, Serializable{

    private KhachHang khachHang;
    private ArrayList<HangHoa> dsHangBan;

    public KhachHang getKhachHang() {
        return khachHang;
    }

    public void setKhachHang(KhachHang khachHang) {
        this.khachHang = khachHang;
    }

    public ArrayList<HangHoa> getDsHangBan() {
        return dsHangBan;
    }

    public void setDsHangBan(ArrayList<HangHoa> dsHangBan) {
        this.dsHangBan = dsHangBan;
    }
    
    public DSMH(){
        khachHang = new KhachHang();
        dsHangBan=new ArrayList<>();
    }
    @Override
    public void nhap() {
       
        try {
            System.out.println("Nhap thong tin khach hang: ");
            nhapKhachHang();
            System.out.println("Nhap ds hang ban: ");
            nhapDSHH();
        } catch (IOException ex) {
            Logger.getLogger(DSMH.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DSMH.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private void nhapDSHH() throws IOException, FileNotFoundException, ClassNotFoundException{
        String maHH="";
        do{
            System.out.println("Nhap ma hang ban: ");
            maHH = new Scanner(System.in).nextLine();
            if(maHH.equals("*"))
                break;
            HangHoa hh= new XuLyHH().timKiemHH(maHH);
            if(hh!=null){
                System.out.println("nhap so luong ban: ");
                hh.setSoLuongBan(new Scanner(System.in).nextInt());
                dsHangBan.add(hh);
            }
            else
                System.out.println("Ma hang khong tai trong kho!");
            
        }while(true);
    }
    
    private void nhapKhachHang() throws IOException, FileNotFoundException, ClassNotFoundException{
        String maKH="";
        System.out.println("Nhap ma khach hang can tim: ");
        maKH =new Scanner(System.in).nextLine();
        KhachHang kh = new XuLyKH().timKiemKH(maKH);
        if(kh==null){
            System.out.println("Khach hang moi, nhap du lieu vao he thong");
            kh = new KhachHang();
            kh.nhap();
            new XuLyKH().ghiFileKhachHang(kh);
            
        }
        khachHang = kh; 
    }

    public void hienDSMH(){
        System.out.println("Thong tin khach hang: ");
        System.out.println(""+khachHang.toString());
        System.out.println("Danh sach mat hang:");
        for (HangHoa hangHoa : dsHangBan) {
            double thanhTien = hangHoa.getGiaBan()*hangHoa.getSoLuongBan();
            String kq = hangHoa.toString() +", thanh tien: " + thanhTien;
            System.out.println(""+kq);
        }
    }
    
    public void sapXep(){
        Collections.sort(dsHangBan, new Comparator<HangHoa>() {
            @Override
            public int compare(HangHoa o1, HangHoa o2) {
                return o1.getTenHang().compareTo(o2.getTenHang());
            }
        });
    }
    
}
