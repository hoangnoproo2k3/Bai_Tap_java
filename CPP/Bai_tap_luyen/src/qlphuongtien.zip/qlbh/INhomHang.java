/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.qlbh;

/**
 *
 * @author maithuyha
 */
public interface INhomHang {
    public static final String THOITRANG="Hang thoi trang";
    public static final String GIADUNG="Hang gia dung";
    public static final String DIENMAY="Hang dien may";
    public static final String TIEUDUNG="Hang tieu dung";
}
