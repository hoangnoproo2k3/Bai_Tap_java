/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.qlbh;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author maithuyha
 */
public class XuLyHH {
    ArrayList<HangHoa> lshh = new ArrayList<>();
    public static final String FNAME="HangHoa.txt";
    public void ghiFileHH(HangHoa hh) throws FileNotFoundException, IOException{
        File F = new File(FNAME);
        //kiem tra xem file da ton tai chua
        boolean append =F.exists();
        FileOutputStream fout =new FileOutputStream(F, append);
        AppendObjectOutputStream out = 
                new AppendObjectOutputStream(fout, append);
        //ghi doi tuong hh vao file
        out.writeObject(hh);
        //dong file
        fout.close();
        out.close();
    }
    
    public void docFileHH() throws FileNotFoundException, IOException, ClassNotFoundException{
        lshh.clear();
        boolean isCheck=true;
        FileInputStream fin = new FileInputStream(FNAME);
        ObjectInputStream in = new ObjectInputStream(fin);
        while(isCheck){
            try {
                HangHoa hh =(HangHoa) in.readObject();
                //them doi vao lshh
                lshh.add(hh);
            } catch (EOFException e) {
                isCheck=false;
            }
        }
        //dong file
        fin.close();
        in.close();
    }
    public void hienDSHH() throws IOException, FileNotFoundException, ClassNotFoundException{
        //thuc hien doc du lieu tu file vao lshh
        docFileHH();
        //hien danh sach hh vua doc tu file
        for (HangHoa hangHoa : lshh) {
            System.out.println(""+ hangHoa.toString());
        }
    }
    
    public void nhapDSHH() throws IOException{
        int soLuong;
        System.out.println("Nhap so luong hang hoa: ");
        soLuong =new Scanner(System.in).nextInt();
        HangHoa hh=null;
        for(int i=0; i<soLuong;i++){
            hh = new HangHoa();
            hh.nhap();
            //goi ham ghi doi tuong hh vao file
            ghiFileHH(hh);
        }
    }
    
    public HangHoa timKiemHH(String maHang) throws IOException, FileNotFoundException, ClassNotFoundException{
        //doc du lieu tu file
        docFileHH();
        //thuc hien tim kiem hang hoa tren ds doc tu file
   
        for (HangHoa hangHoa : lshh) {
            if(hangHoa.getMaHang().equalsIgnoreCase(maHang)){
                return hangHoa;
            }
        }
        return null;
    }
}
