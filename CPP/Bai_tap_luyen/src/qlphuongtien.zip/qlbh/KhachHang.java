/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.qlbh;

import java.io.Serializable;
import java.util.Scanner;

/**
 *
 * @author maithuyha
 */
public class KhachHang implements IHoatDong, Serializable{

    private String maKH;
    private String tenKH;
    private String diaChi;
    private String soDT;

    @Override
    public String toString() {
        return "KhachHang{" + "maKH=" + maKH + ", tenKH=" + tenKH + ", diaChi=" + diaChi + ", soDT=" + soDT + '}';
    }
    
    @Override
    public void nhap() {
        System.out.println("Nhap ma kh: ");
        maKH =new Scanner(System.in).nextLine();
        System.out.println("Nhap ten kh: ");
        tenKH=new Scanner(System.in).nextLine();
        System.out.println("Nhap dia chi: ");
        diaChi =new Scanner(System.in).nextLine();
        System.out.println("Nhap so DT: ");
        soDT =new Scanner(System.in).nextLine();
    }

    public String getMaKH() {
        return maKH;
    }

    public void setMaKH(String maKH) {
        this.maKH = maKH;
    }

    public String getTenKH() {
        return tenKH;
    }

    public void setTenKH(String tenKH) {
        this.tenKH = tenKH;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getSoDT() {
        return soDT;
    }

    public void setSoDT(String soDT) {
        this.soDT = soDT;
    }
    
}
