/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.qlbh;

import java.io.Serializable;
import java.util.Scanner;

/**
 *
 * @author maithuyha
 */
public class HangHoa implements INhomHang, IHoatDong, Serializable{
    private String maHang;
    private String tenHang;
    private String nhomHang;
    private double giaBan;
    private int soLuongBan;
    

    @Override
    public void nhap() {
        System.out.println("Nhap ma hang: ");
        maHang = new Scanner(System.in).nextLine();
        System.out.println("Nhap ten hang: ");
        tenHang =new Scanner(System.in).nextLine();
        System.out.println("Nhap gia ban: ");
        giaBan = new Scanner(System.in).nextDouble();
        int chon;
        do{
             System.out.println("Chon nhom hang: ");
             System.out.println("1. Hang thoi trang");
             System.out.println("2. Hang dien may");
             System.out.println("3. Hang tieu dung");
             System.out.println("4. Hang gia dung");
             System.out.println("5. Ket thuc");
             chon = new Scanner(System.in).nextInt();
             switch(chon){
                 case 1:
                     nhomHang = THOITRANG;
                     break;
                 case 2:
                     nhomHang = DIENMAY;
                     break;
                 case 3:
                     nhomHang = TIEUDUNG;
                     break;
                 case 4:
                     nhomHang = GIADUNG;
                     break;
                 case 5:
                     break;
                 default:
                     break;
             }
        }while(chon!=5);
       
    }

    public String getMaHang() {
        return maHang;
    }

    public void setMaHang(String maHang) {
        this.maHang = maHang;
    }

    public String getTenHang() {
        return tenHang;
    }

    public void setTenHang(String tenHang) {
        this.tenHang = tenHang;
    }

    public String getNhomHang() {
        return nhomHang;
    }
    
    public double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    public int getSoLuongBan() {
        return soLuongBan;
    }

    public void setSoLuongBan(int soLuongBan) {
        this.soLuongBan = soLuongBan;
    }

    @Override
    public String toString() {
        return "HangHoa{" + "maHang=" + maHang + ", tenHang=" + tenHang + ", nhomHang=" + nhomHang + ", giaBan=" + giaBan + ", soLuongBan=" + soLuongBan + '}';
    }
    
    
    
}
