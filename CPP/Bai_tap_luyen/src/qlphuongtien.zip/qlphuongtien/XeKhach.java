/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.kethua.qlphuongtien;

/**
 *
 * @author maithuyha
 */
public class XeKhach extends PhuongTien implements IThue{
    private int soCho;

    public XeKhach() {
    }

    public XeKhach(int soCho) {
        this.soCho = soCho;
    }
    
    public double thueTieuThu(){
        if(soCho >=5)
            return 0.3;
        else
            return 0.5;
    }

    @Override
    public double tinhThue() {
        return getGiaTri()*(getVAT() + getThueTB() + thueTieuThu());
    }

    @Override
    public double getVAT() {
        return 0.1;
    }

    @Override
    public double getThueTB() {
        return 0.2;
    }
    
}
