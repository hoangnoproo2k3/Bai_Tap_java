/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.kethua.qlphuongtien;

import java.util.Scanner;

/**
 *
 * @author maithuyha
 */
public class QLPT {
    public static void main(String[] args) {
        XeMay xeMay = new XeMay();
        System.out.println("Nhap ten: ");
        xeMay.setTenPT(new Scanner(System.in).nextLine());
        System.out.println("Nhap gia tri: ");
        xeMay.setGiaTri(new Scanner(System.in).nextDouble());
        System.out.println("Thong tin cua xe may: ");
        System.out.println("" + xeMay.toString() +" thue phai nop: " + xeMay.tinhThue());
    }
}
