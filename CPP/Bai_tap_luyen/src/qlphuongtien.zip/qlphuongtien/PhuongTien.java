/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.kethua.qlphuongtien;

/**
 *
 * @author maithuyha
 */
public abstract class PhuongTien {
    private String tenPT;
    private double giaTri;

    public PhuongTien() {
    }

    public PhuongTien(String tenPT, double giaTri) {
        this.tenPT = tenPT;
        this.giaTri = giaTri;
    }

    public String getTenPT() {
        return tenPT;
    }

    public void setTenPT(String tenPT) {
        this.tenPT = tenPT;
    }

    public double getGiaTri() {
        return giaTri;
    }

    public void setGiaTri(double giaTri) {
        this.giaTri = giaTri;
    }

    @Override
    public String toString() {
        return "PhuongTien{" + "tenPT=" + tenPT + ", giaTri=" + giaTri + '}';
    }
    
    public abstract double tinhThue();
}
