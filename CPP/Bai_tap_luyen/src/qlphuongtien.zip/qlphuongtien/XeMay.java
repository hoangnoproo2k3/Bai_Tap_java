/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.kethua.qlphuongtien;

/**
 *
 * @author maithuyha
 */
public class XeMay extends PhuongTien implements IThue{

    @Override
    public double tinhThue() {
        return getGiaTri()*(getVAT() + getThueTB());
    }
 
    @Override
    public double getVAT() {
        return 0.1;
    }

    @Override
    public double getThueTB() {
       return 0.05;
    }
    
}
