/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package th_bai14;

/**
 *
 * @author YaosuHuy
 */
public XEKHACH extends PHUONGTIEN implements ITHUE{
    private int soCho;

    public XEKHACH() {
    }

    public XEKHACH(int soCho) {
        this.soCho = soCho;
    }
    
    public double thueTieuThu(){
        if(soCho >=5)
            return 0.3;
        else
            return 0.5;
    }

    @Override
    public double tinhThue() {
        return getGiaTri()*(getVAT() + getThueTB() + thueTieuThu());
    }

    @Override
    public double getVAT() {
        return 0.1;
    }

    @Override
    public double getThueTB() {
        return 0.2;
    }
    
}
