/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package th_bai14;

/**
 *
 * @author YaosuHuy
 */
public abstract class PHUONGTIEN {
    private String tenPT;
    private double giaTri;

    public PHUONGTIEN() {
    }

    public PHUONGTIEN(String tenPT, double giaTri) {
        this.tenPT = tenPT;
        this.giaTri = giaTri;
    }

    public String getTenPT() {
        return tenPT;
    }

    public void setTenPT(String tenPT) {
        this.tenPT = tenPT;
    }

    public double getGiaTri() {
        return giaTri;
    }

    public void setGiaTri(double giaTri) {
        this.giaTri = giaTri;
    }

    @Override
    public String toString() {
        return "PhuongTien{" + "tenPT=" + tenPT + ", giaTri=" + giaTri + '}';
    }
    
    public abstract double tinhThue();
}