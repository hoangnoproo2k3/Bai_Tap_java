/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package th_bai14;

/**
 *
 * @author YaosuHuy
 */
public class XETAI extends PHUONGTIEN implements ITHUE{

    @Override
    public double tinhThue() {
        return getGiaTri()*(getVAT()+getThueTB());
    }

    @Override
    public double getVAT() {
        return 0.1;
    }

    @Override
    public double getThueTB() {
       return 0.02;
    }{
    
}
