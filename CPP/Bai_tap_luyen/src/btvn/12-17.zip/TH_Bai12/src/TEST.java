
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author YaosuHuy
 */
public class TEST {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList <HOCSINH> lst = new ArrayList();
        int n;
        Scanner sc = new Scanner (System.in);
        System.out.println("Nhap so hoc sinh");
        n = sc.nextInt();
        for(int i=0; i<n; i++){
            HOCSINH hs = new HOCSINH();
            hs.nhap();
            lst.add(hs);            
        }
        
        System.out.println("DS Hoc Sinh: ");
        for(HOCSINH hs:lst){
            hs.hien();
        }
        
    }
    
}
