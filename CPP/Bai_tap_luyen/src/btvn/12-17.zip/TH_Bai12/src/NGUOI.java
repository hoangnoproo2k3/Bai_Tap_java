
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author YaosuHuy
 */
public class NGUOI {
    private String hoTen;
    private String gioiTinh;
    
    public void nhap(){
        Scanner sc = new Scanner (System.in);
        System.out.println("Nhap ho ten: ");
        hoTen = sc.nextLine();
        System.out.println("Nhap gioi tinh: ");
        gioiTinh = sc.nextLine();
    }
    
    public void hien()
    {
        System.out.printf("\n %15s", hoTen);
        System.out.printf("%7d", gioiTinh);
        
    }
}
