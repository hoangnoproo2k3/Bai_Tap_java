
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author YaosuHuy
 */
public class HOCSINH extends NGUOI{
    private String tenLop;
    
    public void nhap(){
        super.nhap();
        Scanner sc = new Scanner (System.in);
        System.out.println("Nhap ten lop: ");
        tenLop = sc.nextLine();
    }
    
    public void hien(){
        super.hien();
        System.out.printf("%7.1f", tenLop);
    }
}
