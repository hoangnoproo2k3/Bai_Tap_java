
import java.awt.*;
import java.awt.event.*;
public class BieuDo extends Frame implements ActionListener {

    //Khai báo các thành phần giao diện
    Label lbR,lbB,lbG,lbY;
    TextField txtRed,txtBlue,txtGreen,txtYellow;
    Button btnDraw;
    
    public BieuDo()
    {
        //Khởi tạo và cấp phát các điều khiển
        lbR = new Label("Red:");
        lbB = new Label("Blue:");
        lbG = new Label("Green:");
        lbY = new Label("Yellow:");
        
        txtRed = new TextField("70", 8);
        txtBlue = new TextField("50", 8);
        txtGreen = new TextField("100", 8);
        txtYellow = new TextField("80", 8);
        
        btnDraw = new Button("Draw");
        
        //Đẩy các điều khiển lên giao diện
        setLayout(new FlowLayout()); //Chọn kiểu layout, cái nào viết trước thì hiển thị trước
        add(lbR); add(txtRed);
        add(lbB); add(txtBlue);
        add(lbG); add(txtGreen);
        add(lbY); add(txtYellow);
        add(btnDraw);
        
        //Đăng ký các điều khiển với bộ xử lý sự kiện
        btnDraw.addActionListener(this);
    }
    public void paint(Graphics g)
    {
        int r, b, gr, y;
        r = Integer.parseInt(txtRed.getText()); //Chuyển kiểu dữ liệu từ String sang int
        b = Integer.parseInt(txtBlue.getText());
        gr = Integer.parseInt(txtGreen.getText());
        y = Integer.parseInt(txtYellow.getText());
        
        g.drawLine(50, 90, 50, 350); //Trục tung
        g.drawLine(50, 350, 550, 350); // Trục hoành
        
        //Cột red
        g.setColor(Color.red); //Tạo màu cho cột
        g.drawString(txtRed.getText(), 138, 350-r-8); //Hiện chữ trên các cột
        g.fillRect(120, 350-r, 50, r); //Vẽ cột có màu
        
        //Cột Blue
        g.setColor(Color.blue);
        g.drawString(txtBlue.getText(), 220, 350-b-8);
        g.fillRect(200, 350-b, 50, b);
        
        //Cột Green
        g.setColor(Color.green);
        g.drawString(txtGreen.getText(), 295, 350-gr-8);
        g.fillRect(280, 350-gr, 50, gr);
        
        //Cột Yellow
        g.setColor(Color.yellow);
        g.drawString(txtYellow.getText(), 380, 350-y-8);
        g.fillRect(360, 350-y, 50, y);
    }
    
    //Định nghĩa hàm xử lý sự kiện
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==btnDraw)
        {
            repaint();
        }
    }
    //Hàm main
    public static void main(String[] args) {
        BieuDo t = new BieuDo();
        t.setVisible(true); //Để cửa sổ ở chế độ nhìn thấy được
        t.setSize(600, 400); //set size cho cửa sổ
        //t.setResizable(false);//Không cho sửa size cửa sổ
        
        //Để thoát chương trình bằng dấu X trên cửa sổ
        t.addWindowListener(new WindowAdapter()
            {
                public void windowClosing(WindowEvent e)
                {
                    System.exit(0);
                }
            }
        );
    }
}
 
