/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package th_bai13;

import java.util.Scanner;

/**
 *
 * @author YaosuHuy
 */
public abstract class GIANGVIEN extends CANBO implements LUONG {
    private String khoa;
    
    public float tinhLuong(){
        return this.heSoLuong*1650000+this.heSoLuong*1650000*0.2f;
    }
    public void nhap(){
        super.nhap();
        System.out.print("Nhap khoa: ");
        this.khoa = new Scanner(System.in).nextLine();
    }
    
    public void hien(){
        super.hien();
        System.out.println("Khoa: "+khoa);
        System.out.println("Luong: "+tinhLuong());
    }
}
