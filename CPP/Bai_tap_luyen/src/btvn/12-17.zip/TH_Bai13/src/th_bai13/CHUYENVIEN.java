/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package th_bai13;

import java.util.Scanner;

/**
 *
 * @author YaosuHuy
 */
public abstract class CHUYENVIEN extends CANBO implements LUONG {
    private String phong;
    
    public float tinhLuong(){
        return this.heSoLuong*1650000;
    }
    
    public void nhap(){
        super.nhap();
        System.out.println("Nhap phong: ");
        this.phong = new Scanner(System.in).nextLine();
    }
    
    public void hien(){
        super.hien();
        System.out.println("Phong: "+phong);
        System.out.println("Luong: "+tinhLuong());
    }

    
}
