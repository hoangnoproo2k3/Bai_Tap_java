/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package th_bai13;

import java.util.ArrayList;

/**
 *
 * @author YaosuHuy
 */
public class DSCANBO {
    ArrayList<CANBO> ds = new ArrayList<CANBO>();
    CANBO cb;
    public void nhapDs(int chon){
        switch (chon) {
        case 1:
            cb = new CHUYENVIEN() {
            @Override
            public float tinhluong() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };
            cb.nhap();
            ds.add(cb);
            break;
        case 2:
            cb = new GIANGVIEN() {
            @Override
            public float tinhluong() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };
            cb.nhap();
            ds.add(cb);
            break;
        case 3:
            cb = new QUANLY() {
            @Override
            public float tinhluong() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };
            cb.nhap();
            ds.add(cb);
            break;
        case 4:
            this.xuatDs();
            break;

        default:
            break;
        }
    }

    public void xuatDs(){
        for (CANBO cb : ds) {
                cb.hien();
        }
    }
}
