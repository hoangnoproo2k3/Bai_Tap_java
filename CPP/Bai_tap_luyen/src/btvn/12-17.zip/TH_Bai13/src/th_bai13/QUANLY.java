/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package th_bai13;

import java.util.Scanner;

/**
 *
 * @author YaosuHuy
 */
public abstract class QUANLY extends CANBO implements LUONG {
    private float heSo;
    private String phong;
    private String khoa;
    
    public float tinhLuong(){
        return(this.heSoLuong+this.heSo)*1650000;
    }
    public void nhap(){
        super.nhap();
        System.out.print("Nhap phong: ");
        this.phong = new Scanner(System.in).nextLine();
        System.out.print("Nhap khoa: ");
        this.khoa = new Scanner(System.in).nextLine();
        System.out.print("Nhap HSL Phu Cap: ");
        this.heSoLuong = new Scanner(System.in).nextFloat();
    }
    
    public void hien(){
        super.hien();
        System.out.println("Phong: "+this.phong);
        System.out.println("Khoa: "+this.khoa);
        System.out.println("Luong: "+tinhLuong());
    }
}
