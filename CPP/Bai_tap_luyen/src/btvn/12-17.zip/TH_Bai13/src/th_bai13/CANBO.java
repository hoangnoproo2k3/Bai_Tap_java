/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package th_bai13;

import java.util.Scanner;

/**
 *
 * @author YaosuHuy
 */
public class CANBO {
    String hoTen;
    String diaChi;
    int tuoi;
    float heSoLuong;

    public CANBO(String hoTen, String diaChi, int tuoi, float heSoLuong) {
        this.hoTen = hoTen;
        this.diaChi = diaChi;
        this.tuoi = tuoi;
        this.heSoLuong = heSoLuong;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public void setHeSoLuong(float heSoLuong) {
        this.heSoLuong = heSoLuong;
    }

    public String getHoTen() {
        return hoTen;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public int getTuoi() {
        return tuoi;
    }

    public float getHeSoLuong() {
        return heSoLuong;
    }
    
    public void nhap()
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Nhap ten: ");
        hoTen = sc.nextLine();
        System.out.println("Nhap dia chi: ");
        diaChi = sc.nextLine();
        System.out.println("Nhap tuoi: ");
        tuoi = sc.nextInt();
        System.out.println("Nhap he so luong: ");
        heSoLuong = sc.nextFloat();
    }
    
    public void hien(){
        System.out.println("Ten: "+hoTen);
        System.out.print("\tDia chi: "+diaChi);
        System.out.print("\tTuoi: "+tuoi);
        System.out.print("\tHe so luong: "+heSoLuong);
    }
}
