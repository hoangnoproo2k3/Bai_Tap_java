/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package th_bai13;

import java.util.Scanner;

/**
 *
 * @author YaosuHuy
 */
public class TH_Bai13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DSCANBO dscb = new DSCANBO();
        int chon;
        do {
            System.out.println("=========MENU=========");
            System.out.println("1.Chuyen vien  ");
            System.out.println("2.Giang vien  ");
            System.out.println("3.Ten quan ly  ");
            System.out.println("4.Hien danh sach  ");
            System.out.println("0.Thoat.  ");
            System.out.print("Chon so: ");
            chon = new Scanner(System.in).nextInt();
            System.out.println("======================");
            dscb.nhapDs(chon);
        } while (chon != 0);
    }
    
    
}
