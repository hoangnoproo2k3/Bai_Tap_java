/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.qlbh;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import sun.rmi.server.MarshalInputStream;

/**
 *
 * @author maithuyha
 */
public class XuLDSMH {
    ArrayList<DSMH> lsdsmh = new ArrayList<>();
    public static final String FNAME="dsmh.dat";
    
    public void ghiFileDSMH(DSMH dsmh) throws FileNotFoundException, IOException{
        File f = new File(FNAME);
        boolean append = f.exists();
        //khai bao cac doi tuong xu ly file
        FileOutputStream fout = new FileOutputStream(f, append);
        AppendObjectOutputStream out = new AppendObjectOutputStream(fout, append);
        //thuc hien ghi doi tuong dsmh vao file
        out.writeObject(dsmh);
        //dong file 
        fout.close();
        out.close();
    }
    
    public void docFileDSMH() throws FileNotFoundException, IOException, ClassNotFoundException{
        lsdsmh.clear();
        FileInputStream fin = new FileInputStream(FNAME);
        ObjectInputStream in = new ObjectInputStream(fin);
        boolean isCheck = true;
        while(isCheck){
            try {
                DSMH dsmh = (DSMH)in.readObject();
                lsdsmh.add(dsmh);
            } catch (EOFException e) {
                isCheck=false;
            }
        }
        //dong file
        fin.close();
        in.close();
    }
    
    public void taoHoaDon() throws IOException{
        DSMH dsmh = new DSMH();
        dsmh.nhap();
        System.out.println("Ghi hoa don vao file: ");
        ghiFileDSMH(dsmh);
    }
    
    public void sapXep(int chon) throws IOException, FileNotFoundException, ClassNotFoundException{
       
        docFileDSMH();
        if(chon==1){
            //sap xep theo ten khach hang
            for(int i=0; i< lsdsmh.size()-1;i++)
                for(int j=i+1;j<lsdsmh.size();j++){
                    if(lsdsmh.get(i).getKhachHang().getTenKH().
                            compareTo(lsdsmh.get(j).getKhachHang().getTenKH())>0){
                        DSMH dsmh = lsdsmh.get(i);
                        lsdsmh.set(i,lsdsmh.get(j));
                        lsdsmh.set(j,dsmh);
                    }
                }
        }else if(chon==2){
            //sap xep theo ten hang hoa
            for (DSMH dsmh : lsdsmh) {
                dsmh.sapXep();
            }
        }else{
            Collections.sort(lsdsmh, new Comparator<DSMH>() {
                @Override
                public int compare(DSMH o1, DSMH o2) {
                    return o1.getKhachHang().getMaKH().compareTo(o2.getKhachHang().getMaKH()); //To change body of generated methods, choose Tools | Templates.
                }
            });
        }
    }
    
    public void hienDS(){
        for (DSMH dsmh : lsdsmh) {
            dsmh.hienDSMH();
        }
    }
}
