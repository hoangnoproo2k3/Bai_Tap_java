/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.qlbh;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author maithuyha
 */
public class QLBH {
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
       int chon;
        XuLDSMH xldsmh = new XuLDSMH();
        do{
            menu();
            System.out.println("Hay chon 1-5: ");
            chon = new Scanner(System.in).nextInt();
            switch(chon){
                case 1:
                    System.out.println("Nhap thong tin mat hang ");
                    new XuLyHH().nhapDSHH();
                    break;
                case 2:
                    System.out.println("Nhap thong tin khach hang ");
                    new XuLyKH().nhapDSKH();
                    break;
                case 3:
                    System.out.println("Lap hoa don ");
                    xldsmh.taoHoaDon();
                    break;
                case 4:
                    while(true){
                        System.out.println("Chon tieu chi sap xep ");
                        System.out.println("1. Sap xep theo ten khach hang");
                        System.out.println("2. Sap xep theo ten mat hang ");
                        int option = new Scanner(System.in).nextInt();
                        if(option==1||option==2){
                            xldsmh.sapXep(option);
                        }else{
                            break;
                        }
                    }
                    System.out.println("hien danh sach sau khi sap xep ");
                    xldsmh.hienDS();
                    break;
                case 5:
                    System.exit(0);
                 
            }
        }while(chon!=5);
    }
    
    public static void menu(){
        System.out.println("Quan ly ban hang ");
        System.out.println("1. nhap thong tin mat hang va ghi file ");
        System.out.println("2. nhap thong tin khach hang va ghi file ");
        System.out.println("3. lap hoa don mua hang va ghi file ");
        System.out.println("4. sap xep ");
        System.out.println("5. ket thuc");
        
    }
}
