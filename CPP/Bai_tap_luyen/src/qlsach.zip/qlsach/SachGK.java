/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.kethua.qlsach;

import java.util.Date;

/**
 *
 * @author maithuyha
 */
public class SachGK extends Sach{
    //cu: false, moi: true
   private boolean tinhTrang;

    public SachGK() {
        //goi phuong thuc khoi tao k tham so cua lop cha
        super();
    }

    public SachGK(boolean tinhTrang) {
        super();
        this.tinhTrang = tinhTrang;
    }

    public SachGK(boolean tinhTrang, String maSach,
            Date ngayNhap, double donGia, String nhaXB) {
        super(maSach, ngayNhap, donGia, nhaXB);
        this.tinhTrang = tinhTrang;
    }

    public boolean isTinhTrang() {
        return tinhTrang;
    }

    public void setTinhTrang(boolean tinhTrang) {
        this.tinhTrang = tinhTrang;
    }

    @Override
    public String toString() {
        String tg="";
        if(isTinhTrang())
            tg ="moi";
        else
            tg ="cu";
        //goi phuong thuc toString cua lop cha thong qua tu khoa super
        return "SachGK{" +super.toString() + "tinhTrang[" + tg + "], thanh tien " + thanhTien()+ '}';
    }
   
    public double thanhTien(){
        if(isTinhTrang())
            return getDonGia()*getSoLuong();
        else
            return getDonGia()*getSoLuong()*0.5;
    }
   
}
