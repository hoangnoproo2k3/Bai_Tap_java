/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mtha.kethua.qlsach;

import java.util.Date;

/**
 *
 * @author maithuyha
 */
public class SachTK extends Sach{
    private double thue;

    public SachTK() {
    }

    public SachTK(double thue, 
            String maSach, Date ngayNhap, double donGia, String nhaXB) {
        super(maSach, ngayNhap, donGia, nhaXB);
        this.thue = thue;
    }

    public double getThue() {
        return thue;
    }

    public void setThue(double thue) {
        this.thue = thue;
    }
    public double thanhTien(){
        return getSoLuong()*getDonGia()*(1+thue);
    }

    @Override
    public String toString() {
        return "SachTK{"+super.toString() + "thue [" + thue + "], thanh tien: " + thanhTien()+ '}';
    }
    
    
}
